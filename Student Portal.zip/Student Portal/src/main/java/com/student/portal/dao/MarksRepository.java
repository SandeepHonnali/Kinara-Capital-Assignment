package com.student.portal.dao;

import org.springframework.data.repository.CrudRepository;

import com.student.portal.entity.Marks;

public interface MarksRepository extends CrudRepository<Marks, Integer> {

}
